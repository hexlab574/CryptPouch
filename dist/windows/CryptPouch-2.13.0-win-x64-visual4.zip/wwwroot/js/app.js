// Small helpers the Blazor pages call through JSInterop.
window.cp = {
    copy: async function (text) {
        if (!text) return false;
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
                return true;
            }
        } catch (e) {
            // WebView may refuse the async clipboard API; fall through.
        }
        const area = document.createElement('textarea');
        area.value = text;
        area.style.position = 'fixed';
        area.style.left = '-9999px';
        area.style.top = '0';
        document.body.appendChild(area);
        area.focus();
        area.select();
        let ok = false;
        try {
            ok = document.execCommand('copy');
        } catch (e) {
            ok = false;
        }
        document.body.removeChild(area);
        if (!ok) throw new Error('copy not available');
        return true;
    },

    // Keep the WebView from scrolling behind the soft keyboard on Android.
    blurActive: function () {
        if (document.activeElement && document.activeElement.blur) {
            document.activeElement.blur();
        }
    },

    // Collapse / expand the nav drawer on phone-sized layouts.
    toggleNav: function () {
        var sidebar = document.querySelector('.sidebar');
        if (!sidebar) return;
        sidebar.classList.toggle('nav-open');
        var isOpen = sidebar.classList.contains('nav-open');
        var btn = document.querySelector('.nav-toggle');
        if (btn) btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    },

    closeNav: function () {
        var sidebar = document.querySelector('.sidebar');
        if (!sidebar) return;
        sidebar.classList.remove('nav-open');
        var btn = document.querySelector('.nav-toggle');
        if (btn) btn.setAttribute('aria-expanded', 'false');
    }
};

// Phone layout is decided here instead of by a CSS media query on purpose:
// the Android WebView inside Blazor reports a viewport width that does not
// match the CSS breakpoint, so the query fired only partially and left the
// desktop grid in place (sidebar 236px tall on the left, nav laid out in one
// horizontal row, page hidden behind it). A touch check plus a width check is
// stable on every platform.
(function () {
    function refresh() {
        if (!window.matchMedia) return;
        var coarse = window.matchMedia('(pointer: coarse)').matches;
        var narrow = window.innerWidth > 0 && window.innerWidth <= 900;
        document.documentElement.classList.toggle('is-mobile', coarse || narrow);
    }

    refresh();
    window.addEventListener('resize', refresh);
    window.addEventListener('orientationchange', refresh);
    document.addEventListener('DOMContentLoaded', refresh);
})();

// Card sheen follows the pointer. Desktop only: on touch the pointer never
// moves, and writing CSS variables per frame costs the Android WebView.
(function () {
    if (!window.matchMedia || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
        return;
    }

    var raf = 0;
    var pending = null;

    function apply() {
        raf = 0;
        var e = pending;
        if (!e) return;
        var card = e.target && e.target.closest ? e.target.closest('.card') : null;
        if (!card) return;
        var rect = card.getBoundingClientRect();
        card.style.setProperty('--mx', (e.clientX - rect.left) + 'px');
        card.style.setProperty('--my', (e.clientY - rect.top) + 'px');
    }

    document.addEventListener('pointermove', function (e) {
        pending = { target: e.target, clientX: e.clientX, clientY: e.clientY };
        if (!raf) raf = requestAnimationFrame(apply);
    }, { passive: true });
})();

